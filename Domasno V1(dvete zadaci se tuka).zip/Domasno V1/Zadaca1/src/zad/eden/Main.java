package zad.eden;

public class Main {
    public static void main(String[] args){
        PC PC1 = new PC();
        PC1.prvMetod(100,2000);
    }
}
