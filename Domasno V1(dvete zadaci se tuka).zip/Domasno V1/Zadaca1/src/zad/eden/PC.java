package zad.eden;

public class PC {
    public int memorija;
    public String tipNaMemorija;
    public int hardDisk;
    public String golemina ="GB";
    public String disk;
    public String ssd;

    public PC () {
        this.memorija=2;
        this.tipNaMemorija="DDR2";
        this.hardDisk=160;
        this.disk="HDD";
        this.ssd="SSD m.2";
    }
    public void prvMetod(int zgolemiMemorija, int novSSDDisk){
        System.out.println("Memorijata bese " + this.memorija+this.golemina+",sega iznesuva "+ (this.memorija+zgolemiMemorija)+this.golemina);
        System.out.println("Tipot na memorijata e "+this.tipNaMemorija+".");
        //System.out.println("HardDisk(HD) ima golemina od "+this.hardDisk+this.golemina+".");
        System.out.println("Noviot disk e "+this.ssd+" i ima golemina od "+(2000+novSSDDisk)+this.golemina+". Prethodno imavme "+this.ssd+" i iznessuvase 2000" +this.golemina);
    }
}

