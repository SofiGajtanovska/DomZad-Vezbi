package zad.dva;

public class Brojac {
    public int brojac;

    public void Zgolemi () {
        this.brojac++;
    }

    public void Reset () {
        this.brojac = 0;
    }

}
