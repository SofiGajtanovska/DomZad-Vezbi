package zad.dva;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        int BrNaFrlanje;

        Brojac Pismo = new Brojac();
        Brojac Glava = new Brojac();

        Scanner sc = new Scanner(System.in);
        System.out.println("Vnesi broj na frlanja na parickata: ");
        BrNaFrlanje = sc.nextInt();

        while (BrNaFrlanje > 0) {
            Pismo.Reset();
            Glava.Reset();

            for (int i = 0; i < BrNaFrlanje; i++) {
                if (Math.random() < 0.5)
                    Pismo.Zgolemi();
                else
                    Glava.Zgolemi();
            }
            System.out.println("Vo " + BrNaFrlanje + " frlanja");
            System.out.println("Padna: " + Pismo.brojac + " pismo/pisma");
            System.out.println("Padna: " + Glava.brojac + " glava/glavi");

            System.out.println("Dokolku sakas povtorno da igras, vnesi broj na frlanja, ako ne VNESI 0: ");
            BrNaFrlanje = sc.nextInt();

        }
        sc.close();
    }
}
